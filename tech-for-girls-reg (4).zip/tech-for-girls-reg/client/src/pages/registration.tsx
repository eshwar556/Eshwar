import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertRegistrationSchema, type InsertRegistration } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Rocket, User, Phone, Mail, GraduationCap, Share2, Upload, CheckCircle, NotebookPen } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

export default function Registration() {
  const { toast } = useToast();
  const [shareCount, setShareCount] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<InsertRegistration>({
    resolver: zodResolver(insertRegistrationSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      college: "",
      department: "",
      shareCount: 0,
    },
  });

  const registrationMutation = useMutation({
    mutationFn: async (data: InsertRegistration & { file?: File }) => {
      const formData = new FormData();
      formData.append("name", data.name);
      formData.append("phone", data.phone);
      formData.append("email", data.email);
      formData.append("college", data.college);
      formData.append("department", data.department);
      formData.append("shareCount", data.shareCount.toString());
      
      if (data.file) {
        formData.append("screenshot", data.file);
      }

      const response = await apiRequest("POST", "/api/registrations", formData);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Registration Successful!",
        description: "Your submission has been recorded. Thanks for being part of Tech for Girls!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleWhatsAppShare = () => {
    if (shareCount < 5) {
      const message = encodeURIComponent("Hey Buddy, Join Tech For Girls Community! 🚀");
      window.open(`https://wa.me/?text=${message}`, '_blank');
      
      const newCount = shareCount + 1;
      setShareCount(newCount);
      form.setValue("shareCount", newCount);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "File size must be less than 5MB",
        variant: "destructive",
      });
      return;
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a valid image or PDF file",
        variant: "destructive",
      });
      return;
    }

    setUploadedFile(file);
  };

  const removeFile = () => {
    setUploadedFile(null);
    const fileInput = document.getElementById('fileUpload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  const onSubmit = (data: InsertRegistration) => {
    registrationMutation.mutate({
      ...data,
      file: uploadedFile || undefined,
    });
  };

  const progressPercentage = (shareCount / 5) * 100;
  const isFormValid = form.formState.isValid && shareCount >= 5;

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full">
          <CardContent className="p-8 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Registration Successful!</h2>
            <p className="text-gray-600 mb-6">Your submission has been recorded. Thanks for being part of Tech for Girls!</p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <CheckCircle className="inline-block text-green-600 mr-2" size={20} />
              <span className="text-green-800 font-medium">Welcome to our community!</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
              <Rocket className="text-primary" size={32} />
              Tech For Girls
            </h1>
            <p className="text-gray-600 mt-2">Join our amazing tech community</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <Card className="shadow-lg">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Registration Form</h2>
              <p className="text-gray-600">Fill in your details to join our tech community</p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Basic Details Section */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                    <User className="text-primary" size={20} />
                    Basic Details
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            Name <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <Phone size={16} />
                            Phone Number <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <Mail size={16} />
                            Email ID <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter your email address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="college"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <GraduationCap size={16} />
                            College <span className="text-red-500">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your college name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="department"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <GraduationCap size={16} />
                            Department <span className="text-red-500">*</span>
                          </FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your department" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Computer Science">Computer Science</SelectItem>
                              <SelectItem value="Information Technology">Information Technology</SelectItem>
                              <SelectItem value="Electronics">Electronics & Communication</SelectItem>
                              <SelectItem value="Software Engineering">Software Engineering</SelectItem>
                              <SelectItem value="Data Science">Data Science</SelectItem>
                              <SelectItem value="Mechanical Engineering">Mechanical Engineering</SelectItem>
                              <SelectItem value="Civil Engineering">Civil Engineering</SelectItem>
                              <SelectItem value="Electrical Engineering">Electrical Engineering</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* WhatsApp Sharing Section */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                    <Share2 className="text-green-600" size={20} />
                    Share & Invite Friends
                  </h3>
                  
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex-1">
                      <p className="text-gray-700 mb-2">Help us grow by sharing with your friends!</p>
                      <p className="text-sm text-gray-600">Click the WhatsApp button 5 times to complete this step</p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">{shareCount}</div>
                        <div className="text-sm text-gray-600">/ 5 shares</div>
                      </div>
                      
                      <Button
                        type="button"
                        onClick={handleWhatsAppShare}
                        disabled={shareCount >= 5}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        <Share2 className="mr-2" size={16} />
                        Share on WhatsApp
                      </Button>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <Progress value={progressPercentage} className="h-2" />
                  </div>
                  
                  {shareCount >= 5 && (
                    <div className="mt-4 p-3 bg-green-100 border border-green-300 rounded-md text-green-800">
                      <CheckCircle className="inline-block mr-2" size={16} />
                      Sharing complete. Please continue with your registration.
                    </div>
                  )}
                </div>

                {/* File Upload Section */}
                <div className="bg-blue-50 rounded-lg p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                    <Upload className="text-blue-600" size={20} />
                    Upload Screenshot
                  </h3>
                  
                  <div className="relative">
                    <label htmlFor="fileUpload" className="block">
                      <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 transition-colors">
                        <Upload className="mx-auto text-blue-400 mb-4" size={48} />
                        <p className="text-gray-700 mb-2">Upload your resume, photo, or any relevant screenshot</p>
                        <p className="text-sm text-gray-500">Click to browse or drag and drop your file here</p>
                        <p className="text-xs text-gray-400 mt-2">Supported formats: JPG, PNG, PDF (Max 5MB)</p>
                      </div>
                    </label>
                    
                    <input
                      type="file"
                      id="fileUpload"
                      accept="image/*,.pdf"
                      onChange={handleFileUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                  </div>
                  
                  {uploadedFile && (
                    <div className="mt-4">
                      <div className="flex items-center gap-3 p-3 bg-white rounded-md border">
                        <Upload className="text-blue-600" size={20} />
                        <div className="flex-1">
                          <div className="font-medium text-gray-900">{uploadedFile.name}</div>
                          <div className="text-sm text-gray-500">{(uploadedFile.size / 1024 / 1024).toFixed(2)} MB</div>
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={removeFile} className="text-red-600 hover:text-red-700">
                          ×
                        </Button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Submit Section */}
                <div className="text-center">
                  <Button
                    type="submit"
                    disabled={!isFormValid || registrationMutation.isPending}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {registrationMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <NotebookPen className="mr-2" size={16} />
                        Submit Registration
                      </>
                    )}
                  </Button>
                  
                  {!isFormValid && (
                    <p className="text-red-600 text-sm mt-2">
                      Please complete all required fields and sharing step
                    </p>
                  )}
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
