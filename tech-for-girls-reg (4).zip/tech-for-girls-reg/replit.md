# Registration Application

## Overview

This is a full-stack registration application built with React, Express, and PostgreSQL. The application allows users to register by providing personal information, uploading a screenshot, and completing a social sharing step. It features a modern UI built with shadcn/ui components and uses Drizzle ORM for database operations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: React Hook Form for form handling, TanStack React Query for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Storage**: DatabaseStorage class replacing in-memory storage
- **File Handling**: Multer for file uploads (in-memory storage)
- **Validation**: Zod for schema validation
- **Development**: Hot module replacement with Vite middleware integration

### Database Schema
The application uses two main tables:
1. **users**: Basic user authentication (id, username, password)
2. **registrations**: Registration data including personal info (name, phone, email, college, department), file metadata, and share count

## Key Components

### Registration Flow
1. **Personal Information**: Name, phone, email, college, and department (separate fields)
2. **Social Sharing**: Users must share to 5 different platforms/groups
3. **Screenshot Upload**: Users upload proof of sharing (JPEG, PNG, GIF, or PDF up to 5MB)
4. **Form Submission**: Data is validated and stored in the database

### File Upload System
- Multer middleware handles file uploads with memory storage
- File type validation (image/jpeg, image/png, image/gif, application/pdf)
- File size limit: 5MB
- File metadata (name, size, type) stored in database

### UI Components
- Modern card-based design with progress indicators
- Responsive layout optimized for mobile and desktop
- Form validation with real-time feedback
- Toast notifications for user feedback
- Loading states and error handling

## Data Flow

1. **User Input**: Form data collected via React Hook Form
2. **Validation**: Client-side validation with Zod schemas
3. **File Upload**: Files processed by Multer middleware
4. **Database Storage**: Registration data stored via Drizzle ORM
5. **Response**: Success/error feedback to user via toast notifications

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon Database connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@hookform/resolvers**: Form validation integration
- **multer**: File upload handling
- **zod**: Schema validation

### UI Dependencies
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: CSS class management
- **lucide-react**: Icon library

## Deployment Strategy

### Development
- Vite dev server with HMR for frontend
- Express server with TypeScript compilation via tsx
- Database migrations managed by Drizzle Kit
- Replit-specific development tools and error overlay

### Production
- Frontend: Vite build outputs to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Database: PostgreSQL via Neon with connection pooling
- Environment: Node.js with ES modules

### Database Management
- Schema defined in `shared/schema.ts`
- Migrations generated in `./migrations` directory
- Database URL required via environment variable

## Changelog
- July 08, 2025. Initial setup
- July 08, 2025. Updated registration form to have separate college and department fields
- July 08, 2025. Added PostgreSQL database with persistent storage

## User Preferences

Preferred communication style: Simple, everyday language.