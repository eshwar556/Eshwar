import { VercelRequest, VercelResponse } from '@vercel/node';
import express from 'express';
import { storage } from '../server/storage';
import { insertRegistrationSchema } from '../shared/schema';
import { z } from 'zod';
import multer from 'multer';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and PDF files are allowed.'));
    }
  },
});

// API Routes
app.get('/api/registrations', async (req, res) => {
  try {
    const registrations = await storage.getAllRegistrations();
    res.json(registrations);
  } catch (error) {
    console.error('Error fetching registrations:', error);
    res.status(500).json({ error: 'Failed to fetch registrations' });
  }
});

app.post('/api/registrations', upload.single('file'), async (req, res) => {
  try {
    const body = req.body;
    
    // Parse the registration data
    const registrationData = insertRegistrationSchema.parse(body);
    
    // Add file information if uploaded
    if (req.file) {
      registrationData.fileName = req.file.originalname;
      registrationData.fileSize = req.file.size;
      registrationData.fileType = req.file.mimetype;
    }
    
    // Save to database
    const registration = await storage.createRegistration(registrationData);
    
    res.status(201).json(registration);
  } catch (error) {
    console.error('Error creating registration:', error);
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: 'Validation error', details: error.errors });
    } else {
      res.status(500).json({ error: 'Failed to create registration' });
    }
  }
});

// Serve static files for non-API routes
app.get('*', (req, res) => {
  // Serve the React app
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />
        <title>Tech For Girls - Registration</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
        <style>
          :root {
            --background: 0 0% 100%;
            --foreground: 222.2 84% 4.9%;
            --card: 0 0% 100%;
            --card-foreground: 222.2 84% 4.9%;
            --popover: 0 0% 100%;
            --popover-foreground: 222.2 84% 4.9%;
            --primary: 262.1 83.3% 57.8%;
            --primary-foreground: 210 40% 98%;
            --secondary: 210 40% 96%;
            --secondary-foreground: 222.2 84% 4.9%;
            --muted: 210 40% 96%;
            --muted-foreground: 215.4 16.3% 46.9%;
            --accent: 210 40% 96%;
            --accent-foreground: 222.2 84% 4.9%;
            --destructive: 0 84.2% 60.2%;
            --destructive-foreground: 210 40% 98%;
            --border: 214.3 31.8% 91.4%;
            --input: 214.3 31.8% 91.4%;
            --ring: 262.1 83.3% 57.8%;
            --radius: 0.5rem;
          }
          
          body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: system-ui, -apple-system, sans-serif;
          }
        </style>
      </head>
      <body>
        <div class="min-h-screen flex items-center justify-center p-4">
          <div class="text-center text-white">
            <h1 class="text-4xl font-bold mb-4">Tech For Girls</h1>
            <p class="text-xl mb-8">Registration System</p>
            <div class="bg-white bg-opacity-10 backdrop-blur-md rounded-lg p-6 max-w-md mx-auto">
              <p class="text-lg mb-4">Your registration website is being deployed!</p>
              <p class="text-sm opacity-80">Please wait for the full deployment to complete.</p>
            </div>
          </div>
        </div>
      </body>
    </html>
  `);
});

export default app;